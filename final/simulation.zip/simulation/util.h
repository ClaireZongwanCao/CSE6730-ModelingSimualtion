#include <time.h>
#include <cstdlib>

#ifndef UTIL_H
#define UTIL_H

// generate a random number between min and max
unsigned int rand_number(unsigned int min, unsigned int max);


#endif // UTIL_H